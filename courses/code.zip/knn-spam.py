import sys
import zlib
import csv
import operator
import matplotlib.pyplot as plt
import random


Python3 = (sys.version_info >= (3,0))
compressor = zlib.compress

###############################################################################
###### READ DATA
###############################################################################

def read_data(csv_file):
    X = []
    Y = []
    with open(csv_file) as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        for row in spamreader:
            X.append(','.join(row[3:len(row)-1]))
            Y.append(int(row[len(row)-1]))
    return X, Y

###############################################################################
###### COMPRESSION DISTANCE
###############################################################################

def compression(TextSample, Encoding='latin-1'):
    """	gets a string compressed and prints compression factor
    """
    if type(TextSample) == str and Python3:
        TextSample = TextSample.encode(Encoding)	# 'latin-1' =   8 bits ASCII
    return len(compressor(TextSample))

def compression_distance(x, y):
    if x == y: return 0
    Zx = compression(x, Encoding='utf-8')
    Zy = compression(y, Encoding='utf-8')
    Zxy = compression(x + y, Encoding='utf-8')
    return (Zxy - min(Zx, Zy)) / max(Zx, Zy)

###############################################################################
###### CLASSIFICATION WITH K-NN
###############################################################################

def get_neighbors(X_train, x_test, k):
    distances = [[i, compression_distance(x_test, X_train[i])] for i in range(len(X_train))]
    distances.sort(key=operator.itemgetter(1))    
    neighbors = [distances[n][0] for n in range(k)]
    return neighbors

def get_label(neighbors, Y_train):
    votes = [0, 0]
    for x in range(len(neighbors)):
        votes[Y_train[x]] += 1
    return 0 if votes[0] > votes[1] else 1
    
def knn(X_train, Y_train, X_test, k):
    return [get_label(get_neighbors(X_train, x_test, k), Y_train) for x_test in X_test]


# Load data
X, Y = read_data('spams/Youtube01-Psy-clean.csv')

new_order = list(range(len(X)))
random.shuffle(new_order)

X = [X[i] for i in new_order]
Y = [Y[i] for i in new_order]

n_train = int(len(X) / 2)
n_test = len(X) - n_train
X_train = X[:n_train]
Y_train = Y[:n_train]
X_test = X[n_train:]
Y_test = Y[n_train:]



# Train classifier

precision = []
for K in range(1, 20):
    Y_pred = knn(X_train, Y_train, X_test, K)
    precision.append(sum([1 for i in range(n_test) if Y_pred[i] == Y_test[i]]) / n_test)

plt.plot(precision)
