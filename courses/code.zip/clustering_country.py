import numpy as np
import random
import requests
import re
from time import sleep
import csv

###############################################################################
#### Google distance
###############################################################################

user_agents = ['ELinks (0.4.3; NetBSD 3.0.2PATCH sparc64; 141x19)',
               'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0',
               'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:14.0) Gecko/20100101 Firefox/14.0.1',
               'Mozilla/5.0 (X11; Linux i686; rv:6.0a2) Gecko/20110615 Firefox/6.0a2 Iceweasel/6.0a2',
               'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.16) Gecko/20080716 (Gentoo) Galeon/2.0.6',
               'Mozilla/5.0 (PLAYSTATION 3; 1.10)',
               'Mozilla/5.0 (OS/2; Warp 4.5; rv:10.0.12) Gecko/20130108 Firefox/10.0.12 SeaMonkey/2.7.2',
               'Opera 9.25 - (Vista)" useragent="Opera/9.25 (Windows NT 6.0; U; en)',
               'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1667.0 Safari/537.36',
               'iTunes/4.2 (Macintosh; U; PPC Mac OS X 10.2)']

def google_number_of_hits(word):
    user_agent = user_agents[random.randint(0, len(user_agents) - 1)]
    
    r = requests.get('http://www.google.com/search',
                     params={'hl':'en',
#                             'rls':'ig',
                             'num':'100',
                             'q':'"' + word + '"',
                             'User-Agent': user_agent
#                             "tbs":"li:1"
                             }
                    )
    if r.status_code == 200:
        htmlPage = r.text
        Match = re.findall("About\s*(\d[^<]+)\s*results", htmlPage)
        try: 
            return int(Match[0].replace(',',''))
        except IndexError:	
            print('Wrong HTML structure')
            return 0
    else:
        raise Exception('Blocked by Google!')

    
def get_google_distance(word1, word2, nb_hits_func=google_number_of_hits, time=20):
    logN = np.log2(25270000000)
    lfx = np.log2(nb_hits_func(word1))
    sleep(15 + time * random.random())
    lfy = np.log2(nb_hits_func(word2))
    sleep(15 + time * random.random())  
    lfxy = np.log2(nb_hits_func(word1 + '+' + word2))
    sleep(15 + time * random.random())  
    lfyx = np.log2(nb_hits_func(word2 + '+' + word1))
    lf_tot = .5 * (lfxy + lfyx)
    return (max(lfx, lfy) - lf_tot)/(logN - min(lfx, lfy))


###############################################################################
#### K-medoids
###############################################################################

def cluster(distances, k=3):

    m = distances.shape[0] # number of points

    # Pick k random medoids.
    curr_medoids = np.array([-1]*k)
    while not len(np.unique(curr_medoids)) == k:
        curr_medoids = np.array([random.randint(0, m - 1) for _ in range(k)])
    old_medoids = np.array([-1]*k) # Doesn't matter what we initialize these to.
    new_medoids = np.array([-1]*k)
   
    # Until the medoids stop updating, do the following:
    while not ((old_medoids == curr_medoids).all()):
        # Assign each point to cluster with closest medoid.
        clusters = assign_points_to_clusters(curr_medoids, distances)

        # Update cluster medoids to be lowest cost point. 
        for curr_medoid in curr_medoids:
            cluster = np.where(clusters == curr_medoid)[0]
            new_medoids[curr_medoids == curr_medoid] = compute_new_medoid(cluster, distances)

        old_medoids[:] = curr_medoids[:]
        curr_medoids[:] = new_medoids[:]

    return clusters, curr_medoids

def assign_points_to_clusters(medoids, distances):
    distances_to_medoids = distances[:,medoids]
    clusters = medoids[np.argmin(distances_to_medoids, axis=1)]
    clusters[medoids] = medoids
    return clusters

def compute_new_medoid(cluster, distances):
    mask = np.ones(distances.shape)
    mask[np.ix_(cluster,cluster)] = 0.
    cluster_distances = np.ma.masked_array(data=distances, mask=mask, fill_value=10e9)
    costs = cluster_distances.sum(axis=1)
    return costs.argmin(axis=0, fill_value=10e9)
    

###############################################################################
#### MAIN
###############################################################################

def read_data(csv_file):
    countries = []
    with open(csv_file) as csvfile:
        spamreader = csv.reader(csvfile, delimiter=' ')
        for row in spamreader:
            countries.append(row[0])
    return countries

countries = read_data('countries/countries.txt')
n_countries = len(countries)

# Associate country to its index
country_indexes = {}
for i in range(n_countries):
    country_indexes[countries[i]] = i

distances = np.zeros((n_countries, n_countries))
with open('countries/total-distances.txt') as csvfile:
    reader = csv.reader(csvfile, delimiter=' ')
    for row in reader:
        i = country_indexes[row[0]]
        j = country_indexes[row[1]]
        distances[i,j] = float(row[2])
        distances[j,i] = float(row[2])


        
# CLUSTERING

K = 2
clusters, curr_medoids = cluster(distances, K)